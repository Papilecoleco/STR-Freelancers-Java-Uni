/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package srt.freelancers;

import java.util.Date;

/**
 *
 * @author papil
 */
public class Tarefas {
    Integer id;
    String nome;
    String descrição;
    Date data;
    Double ContadorHoras;
}
